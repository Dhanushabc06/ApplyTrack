---
name: Artifact service working directory
description: Runtime behavior for commands declared by a multi-service artifact.
---

Commands declared under an artifact service run with that artifact's directory as the working directory. Relative paths to service files should therefore start from the artifact folder, not the workspace root.

**Why:** A backend command using a workspace-root-relative path was resolved twice and failed to start.

**How to apply:** When adding a service to an artifact, confirm its working directory from workflow logs. Use paths relative to the artifact folder; use `../..` when a command needs workspace-root configuration from a nested artifact.
