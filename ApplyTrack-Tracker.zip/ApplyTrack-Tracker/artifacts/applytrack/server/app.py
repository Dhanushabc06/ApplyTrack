import os
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, request


APP_DIR = Path(__file__).resolve().parent
DATABASE_PATH = Path(
    os.environ.get("APPLYTRACK_DATABASE_PATH", APP_DIR / "applytrack.sqlite3")
)
API_PREFIX = "/applytrack-api/api"
APPLICATION_TYPES = {"Internship", "Full-time", "Part-time", "Contract"}
APPLICATION_STATUSES = {"Wishlist", "Applied", "Interview", "Offer", "Rejected"}
INPUT_FIELDS = {
    "company",
    "role",
    "type",
    "status",
    "location",
    "appliedDate",
    "notes",
}
REQUIRED_FIELDS = {"company", "role", "type", "status", "appliedDate"}

app = Flask(__name__)


@contextmanager
def connect_db():
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def init_db():
    with connect_db() as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company TEXT NOT NULL,
                role TEXT NOT NULL,
                type TEXT NOT NULL,
                status TEXT NOT NULL,
                location TEXT NOT NULL DEFAULT '',
                applied_date TEXT NOT NULL,
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        connection.execute(
            "CREATE INDEX IF NOT EXISTS idx_applications_updated_at "
            "ON applications(updated_at DESC)"
        )


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def as_application(row):
    return {
        "id": row["id"],
        "company": row["company"],
        "role": row["role"],
        "type": row["type"],
        "status": row["status"],
        "location": row["location"],
        "appliedDate": row["applied_date"],
        "notes": row["notes"],
        "createdAt": row["created_at"],
        "updatedAt": row["updated_at"],
    }


def validate_payload(payload, partial=False):
    if not isinstance(payload, dict):
        return None, "Request body must be a JSON object."

    unknown = set(payload) - INPUT_FIELDS
    if unknown:
        return None, f"Unknown field(s): {', '.join(sorted(unknown))}."

    if not partial:
        missing = REQUIRED_FIELDS - set(payload)
        if missing:
            return None, f"Missing required field(s): {', '.join(sorted(missing))}."
    elif not payload:
        return None, "Provide at least one field to update."

    clean = {}
    for field in ("company", "role", "location", "notes"):
        if field not in payload:
            continue
        value = payload[field]
        if not isinstance(value, str):
            return None, f"{field} must be text."
        value = value.strip()
        if field in {"company", "role"} and not value:
            return None, f"{field} cannot be empty."
        clean[field] = value

    if "type" in payload:
        if not isinstance(payload["type"], str) or payload["type"] not in APPLICATION_TYPES:
            return None, "Choose a valid application type."
        clean["type"] = payload["type"]

    if "status" in payload:
        if (
            not isinstance(payload["status"], str)
            or payload["status"] not in APPLICATION_STATUSES
        ):
            return None, "Choose a valid application status."
        clean["status"] = payload["status"]

    if "appliedDate" in payload:
        value = payload["appliedDate"]
        if not isinstance(value, str):
            return None, "appliedDate must be a date in YYYY-MM-DD format."
        try:
            date.fromisoformat(value)
        except ValueError:
            return None, "appliedDate must be a date in YYYY-MM-DD format."
        clean["applied_date"] = value

    return clean, None


@app.get(f"{API_PREFIX}/healthz")
def health_check():
    return jsonify({"status": "ok"})


@app.get(f"{API_PREFIX}/applications")
def list_applications():
    search = request.args.get("search", "").strip()
    status = request.args.get("status")
    application_type = request.args.get("type")

    if status and status not in APPLICATION_STATUSES:
        return jsonify({"error": "Choose a valid application status."}), 400
    if application_type and application_type not in APPLICATION_TYPES:
        return jsonify({"error": "Choose a valid application type."}), 400

    clauses = []
    values = []
    if search:
        clauses.append("(company LIKE ? OR role LIKE ? OR location LIKE ?)")
        search_term = f"%{search}%"
        values.extend((search_term, search_term, search_term))
    if status:
        clauses.append("status = ?")
        values.append(status)
    if application_type:
        clauses.append("type = ?")
        values.append(application_type)

    query = "SELECT * FROM applications"
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    query += " ORDER BY updated_at DESC, id DESC"

    with connect_db() as connection:
        rows = connection.execute(query, values).fetchall()
    return jsonify([as_application(row) for row in rows])


@app.post(f"{API_PREFIX}/applications")
def create_application():
    clean, error = validate_payload(request.get_json(silent=True))
    if error:
        return jsonify({"error": error}), 400

    timestamp = now_iso()
    with connect_db() as connection:
        cursor = connection.execute(
            """
            INSERT INTO applications
                (company, role, type, status, location, applied_date, notes, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                clean["company"],
                clean["role"],
                clean["type"],
                clean["status"],
                clean.get("location", ""),
                clean["applied_date"],
                clean.get("notes", ""),
                timestamp,
                timestamp,
            ),
        )
        row = connection.execute(
            "SELECT * FROM applications WHERE id = ?", (cursor.lastrowid,)
        ).fetchone()
    return jsonify(as_application(row)), 201


@app.patch(f"{API_PREFIX}/applications/<int:application_id>")
def update_application(application_id):
    clean, error = validate_payload(request.get_json(silent=True), partial=True)
    if error:
        return jsonify({"error": error}), 400

    column_order = (
        ("company", "company"),
        ("role", "role"),
        ("type", "type"),
        ("status", "status"),
        ("location", "location"),
        ("applied_date", "applied_date"),
        ("notes", "notes"),
    )
    assignments = []
    values = []
    for column, field in column_order:
        if field in clean:
            assignments.append(f"{column} = ?")
            values.append(clean[field])

    assignments.append("updated_at = ?")
    values.extend((now_iso(), application_id))
    with connect_db() as connection:
        cursor = connection.execute(
            f"UPDATE applications SET {', '.join(assignments)} WHERE id = ?", values
        )
        if cursor.rowcount == 0:
            return jsonify({"error": "Application not found."}), 404
        row = connection.execute(
            "SELECT * FROM applications WHERE id = ?", (application_id,)
        ).fetchone()
    return jsonify(as_application(row))


@app.delete(f"{API_PREFIX}/applications/<int:application_id>")
def delete_application(application_id):
    with connect_db() as connection:
        cursor = connection.execute(
            "DELETE FROM applications WHERE id = ?", (application_id,)
        )
    if cursor.rowcount == 0:
        return jsonify({"error": "Application not found."}), 404
    return "", 204


@app.get(f"{API_PREFIX}/dashboard")
def dashboard_summary():
    with connect_db() as connection:
        counts = {
            row["status"]: row["count"]
            for row in connection.execute(
                "SELECT status, COUNT(*) AS count FROM applications GROUP BY status"
            ).fetchall()
        }
        total = sum(counts.values())
        recent = connection.execute(
            "SELECT * FROM applications ORDER BY updated_at DESC, id DESC LIMIT 5"
        ).fetchall()

    return jsonify(
        {
            "total": total,
            "applied": counts.get("Applied", 0),
            "interviews": counts.get("Interview", 0),
            "offers": counts.get("Offer", 0),
            "recentApplications": [as_application(row) for row in recent],
        }
    )


init_db()


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5001"))
    app.run(host="0.0.0.0", port=port)
