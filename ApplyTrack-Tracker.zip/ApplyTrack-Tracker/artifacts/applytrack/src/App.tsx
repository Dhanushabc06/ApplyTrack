import { type FormEvent, type ReactNode, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  getGetApplicationsQueryKey,
  getGetDashboardSummaryQueryKey,
  useCreateApplication,
  useDeleteApplication,
  useGetApplications,
  useGetDashboardSummary,
  useUpdateApplication,
  type Application,
  type ApplicationInput,
  type ApplicationStatus,
  type ApplicationType,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowDownRight,
  ArrowRight,
  BriefcaseBusiness,
  CalendarDays,
  Check,
  ChevronDown,
  CircleHelp,
  FileText,
  Filter,
  MapPin,
  Pencil,
  Plus,
  Search,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  const queryClient = useMemo(() => queryClientRef, []);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [dialog, setDialog] = useState<'form' | 'delete' | null>(null);
  const [selected, setSelected] = useState<Application | null>(null);
  const [notice, setNotice] = useState('');
  const params = useMemo(() => ({
    ...(search.trim() ? { search: search.trim() } : {}),
    ...(statusFilter ? { status: statusFilter as ApplicationStatus } : {}),
  }), [search, statusFilter]);
  const applicationsQuery = useGetApplications(params);
  const summaryQuery = useGetDashboardSummary();
  const createApplication = useCreateApplication();
  const updateApplication = useUpdateApplication();
  const deleteApplication = useDeleteApplication();
  const applications = applicationsQuery.data ?? [];
  const summary = summaryQuery.data;
  const busy = createApplication.isPending || updateApplication.isPending || deleteApplication.isPending;

  const refreshAll = () => {
    void queryClient.invalidateQueries({ queryKey: getGetApplicationsQueryKey() });
    void queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
  };

  const openCreate = () => {
    setSelected(null);
    setNotice('');
    setDialog('form');
  };
  const openEdit = (application: Application) => {
    setSelected(application);
    setNotice('');
    setDialog('form');
  };
  const closeDialog = () => {
    if (busy) return;
    setDialog(null);
    setSelected(null);
    setNotice('');
  };
  const saveApplication = (payload: ApplicationInput) => {
    setNotice('');
    if (selected) {
      updateApplication.mutate({ id: selected.id, data: payload }, {
        onSuccess: () => { refreshAll(); closeDialog(); },
        onError: () => setNotice('We couldn’t save those changes. Please try again.'),
      });
    } else {
      createApplication.mutate({ data: payload }, {
        onSuccess: () => { refreshAll(); closeDialog(); },
        onError: () => setNotice('We couldn’t add that application. Please try again.'),
      });
    }
  };
  const confirmDelete = () => {
    if (!selected) return;
    deleteApplication.mutate({ id: selected.id }, {
      onSuccess: () => { refreshAll(); closeDialog(); },
      onError: () => setNotice('We couldn’t remove this application. Please try again.'),
    });
  };

  return (
    <div className="app-frame min-h-[100dvh]">
      <aside className="sidebar">
        <div className="brand-lockup">
          <div className="brand-mark"><span></span><span></span><span></span></div>
          <span>applytrack</span>
        </div>
        <div className="workspace-label">YOUR WORKSPACE</div>
        <nav aria-label="Main navigation">
          <button className="nav-item active" data-testid="nav-dashboard" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <span className="nav-icon"><BriefcaseBusiness size={17} /></span> Overview
          </button>
          <button className="nav-item" data-testid="nav-applications" onClick={() => document.getElementById('applications')?.scrollIntoView({ behavior: 'smooth' })}>
            <span className="nav-icon"><FileText size={17} /></span> Applications
            <span className="nav-count">{summary?.total ?? '—'}</span>
          </button>
        </nav>
        <div className="sidebar-bottom">
          <div className="encouragement">
            <div className="encouragement-icon"><Sparkles size={16} /></div>
            <p>One step at a time.</p>
            <span>You’re making progress just by showing up.</span>
          </div>
          <div className="sidebar-user">
            <div className="user-avatar">Y</div>
            <div><strong>Your space</strong><span>Early-career journey</span></div>
            <button aria-label="Help" data-testid="button-help" onClick={() => setNotice('Need a hand? Add a note to an application to keep your next step close by.')}><CircleHelp size={17} /></button>
          </div>
        </div>
      </aside>
      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumb"><span>Workspace</span><span className="crumb-slash">/</span><strong>Overview</strong></div>
          <div className="topbar-right"><span className="today-label"><CalendarDays size={15} /> Your job search, in one place</span><button className="mobile-add" onClick={openCreate} data-testid="button-add-application-mobile"><Plus size={17} /> Add</button></div>
        </header>
        <div className="content-wrap">
          <section className="welcome-row rise-in">
            <div>
              <div className="eyebrow"><span className="eyebrow-dot"></span> A LITTLE MORE ORGANIZED</div>
              <h1 className="font-display">Your next chapter<br className="mobile-break" /> starts here.</h1>
              <p className="welcome-copy">Keep track of the opportunities you’re working toward. You’ve got this.</p>
            </div>
            <button className="primary-button add-main" onClick={openCreate} data-testid="button-add-application"><Plus size={17} strokeWidth={2.5} /> Add application</button>
          </section>

          {notice && !dialog && <div className="inline-alert" role="status" data-testid="status-guidance"><span>{notice}</span><button onClick={() => setNotice('')} aria-label="Dismiss message" data-testid="button-dismiss-guidance"><X size={14} /></button></div>}
          {summaryQuery.isError && (
            <div className="inline-alert" role="alert" data-testid="status-summary-error">
              <span>We couldn’t load your overview.</span>
              <button onClick={() => void summaryQuery.refetch()} data-testid="button-retry-summary">Try again <ArrowRight size={14} /></button>
            </div>
          )}
          <section className="summary-grid rise-in-delay" aria-label="Application summary">
            <Metric label="Applications tracked" value={summary?.total} loading={summaryQuery.isLoading} icon={<BriefcaseBusiness size={16} />} accent="mint" caption="Every opportunity, together" testId="metric-total" />
            <Metric label="In progress" value={summary?.applied} loading={summaryQuery.isLoading} icon={<ArrowDownRight size={17} />} accent="sand" caption="Applications sent out" testId="metric-applied" />
            <Metric label="Conversations" value={summary?.interviews} loading={summaryQuery.isLoading} icon={<CalendarDays size={16} />} accent="blue" caption="Interview stages" testId="metric-interviews" />
            <Metric label="Offers" value={summary?.offers} loading={summaryQuery.isLoading} icon={<Sparkles size={16} />} accent="peach" caption="Good things ahead" testId="metric-offers" />
          </section>

          <section className="progress-note">
            <div className="progress-mark"><Sparkles size={18} /></div>
            <div className="progress-message"><strong>Every application is progress.</strong><span>Keep taking small steps. They add up faster than you think.</span></div>
            <span className="progress-decoration">✳</span>
          </section>

          <section className="applications-section" id="applications">
            <div className="section-heading">
              <div><div className="eyebrow">YOUR OPPORTUNITIES</div><h2 className="font-display">Applications <span className="heading-count">{summary?.total ?? ''}</span></h2></div>
              <div className="section-tools">
                <label className="search-box"><Search size={16} /><input aria-label="Search applications" placeholder="Search companies or roles" value={search} onChange={(e) => setSearch(e.target.value)} data-testid="input-search-applications" />{search && <button onClick={() => setSearch('')} aria-label="Clear search" data-testid="button-clear-search"><X size={14} /></button>}</label>
                <label className="filter-box"><Filter size={15} /><select aria-label="Filter by status" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} data-testid="select-status-filter"><option value="">All statuses</option>{statuses.map((status) => <option key={status} value={status}>{status}</option>)}</select><ChevronDown size={14} /></label>
              </div>
            </div>
            {applicationsQuery.isError ? (
              <div className="state-card error-state" role="alert" data-testid="status-applications-error">
                <div className="state-icon"><FileText size={22} /></div><h3>Couldn’t load your applications</h3><p>Your information is still safe. Let’s give it another try.</p><button className="secondary-button" onClick={() => void applicationsQuery.refetch()} data-testid="button-retry-applications">Retry</button>
              </div>
            ) : applicationsQuery.isLoading ? (
              <div className="table-card" data-testid="status-applications-loading"><div className="table-header-skeleton"><i></i><i></i><i></i></div>{[1, 2, 3, 4].map((n) => <div className="skeleton-row" key={n}><i></i><i></i><i></i><i></i></div>)}</div>
            ) : applications.length === 0 ? (
              <div className="state-card empty-state" data-testid="status-applications-empty">
                <div className="empty-illustration"><div className="empty-paper"><span></span><span></span><span></span><b><Check size={13} /></b></div><div className="empty-sun"></div></div>
                <div className="eyebrow">{search || statusFilter ? 'NOTHING MATCHES JUST YET' : 'A FRESH START'}</div>
                <h3>{search || statusFilter ? 'No applications found' : 'Your next opportunity belongs here.'}</h3>
                <p>{search || statusFilter ? 'Try another search or clear your filters to see all applications.' : 'Add the first role you’re interested in. We’ll help you keep the details in one calm, easy place.'}</p>
                {search || statusFilter ? <button className="secondary-button" onClick={() => { setSearch(''); setStatusFilter(''); }} data-testid="button-clear-filters">Clear filters</button> : <button className="primary-button" onClick={openCreate} data-testid="button-empty-add"><Plus size={16} /> Add your first application</button>}
              </div>
            ) : (
              <div className="table-card" data-testid="list-applications">
                <div className="table-scroll"><table><thead><tr><th>COMPANY & ROLE</th><th>TYPE</th><th>STATUS</th><th>LOCATION</th><th>APPLIED</th><th><span className="sr-only">Actions</span></th></tr></thead>
                  <tbody>{applications.map((application) => <ApplicationRow key={application.id} application={application} onEdit={() => openEdit(application)} onDelete={() => { setSelected(application); setNotice(''); setDialog('delete'); }} />)}</tbody>
                </table></div>
                <div className="table-foot"><span>Showing <strong>{applications.length}</strong> {applications.length === 1 ? 'opportunity' : 'opportunities'}{search || statusFilter ? ' matching your filters' : ''}</span><span className="table-foot-right"><span className="foot-dot"></span> Up to date</span></div>
              </div>
            )}
          </section>
          <footer className="page-footer"><span>Small steps. Big possibilities.</span><span>Made for the in-between moments.</span></footer>
        </div>
      </main>
      {dialog === 'form' && <ApplicationDialog application={selected} pending={busy} error={notice} onClose={closeDialog} onSubmit={saveApplication} />}
      {dialog === 'delete' && selected && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) closeDialog(); }}><div className="confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="delete-title" data-testid="dialog-delete-application"><button className="modal-close" onClick={closeDialog} aria-label="Close dialog" data-testid="button-close-delete"><X size={18} /></button><div className="delete-icon"><Trash2 size={19} /></div><h2 id="delete-title" className="font-display">Remove this application?</h2><p>This will remove <strong>{selected.company} · {selected.role}</strong> from your tracker. You can always add it again later.</p>{notice && <div className="form-error" role="alert">{notice}</div>}<div className="dialog-actions"><button className="secondary-button" onClick={closeDialog} disabled={busy} data-testid="button-cancel-delete">Keep it</button><button className="danger-button" onClick={confirmDelete} disabled={busy} data-testid="button-confirm-delete">{busy ? 'Removing…' : 'Remove application'}</button></div></div></div>}
    </div>
  );
}

const queryClientRef = queryClient;

const statuses: ApplicationStatus[] = ['Wishlist', 'Applied', 'Interview', 'Offer', 'Rejected'];
const types: ApplicationType[] = ['Internship', 'Full-time', 'Part-time', 'Contract'];

function Metric({ label, value, loading, icon, accent, caption, testId }: { label: string; value?: number; loading: boolean; icon: ReactNode; accent: string; caption: string; testId: string }) {
  return <article className={`metric-card metric-${accent}`} data-testid={testId}><div className="metric-top"><span>{label}</span><span className="metric-icon">{icon}</span></div>{loading ? <div className="metric-skeleton" /> : <div className="metric-number">{value ?? 0}</div>}<div className="metric-caption">{caption}</div></article>;
}

function ApplicationRow({ application, onEdit, onDelete }: { application: Application; onEdit: () => void; onDelete: () => void }) {
  const initials = application.company.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]?.toUpperCase()).join('') || '?';
  const date = application.appliedDate ? new Date(`${application.appliedDate}T12:00:00`).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '—';
  return <tr data-testid={`row-application-${application.id}`}>
    <td><div className="company-cell"><div className="company-avatar" aria-hidden="true">{initials}</div><div className="company-copy"><strong data-testid={`text-company-${application.id}`}>{application.company}</strong><span>{application.role}</span></div></div></td>
    <td><span className="type-label">{application.type}</span></td><td><StatusBadge status={application.status} /></td>
    <td><span className="location-label"><MapPin size={13} />{application.location || 'Not specified'}</span></td>
    <td><span className="date-label">{date}</span></td>
    <td><div className="row-actions"><button aria-label={`Edit ${application.company}`} onClick={onEdit} data-testid={`button-edit-${application.id}`}><Pencil size={15} /></button><button aria-label={`Delete ${application.company}`} onClick={onDelete} data-testid={`button-delete-${application.id}`}><Trash2 size={15} /></button></div></td>
  </tr>;
}

function StatusBadge({ status }: { status: ApplicationStatus }) {
  return <span className={`status-badge status-${status.toLowerCase()}`} data-testid={`status-${status.toLowerCase()}` }><span></span>{status}</span>;
}

function ApplicationDialog({ application, pending, error, onClose, onSubmit }: { application: Application | null; pending: boolean; error: string; onClose: () => void; onSubmit: (payload: ApplicationInput) => void }) {
  const [company, setCompany] = useState(application?.company ?? '');
  const [role, setRole] = useState(application?.role ?? '');
  const [type, setType] = useState<ApplicationType>(application?.type ?? 'Internship');
  const [status, setStatus] = useState<ApplicationStatus>(application?.status ?? 'Wishlist');
  const [location, setLocation] = useState(application?.location ?? '');
  const [appliedDate, setAppliedDate] = useState(application?.appliedDate?.slice(0, 10) ?? new Date().toISOString().slice(0, 10));
  const [notes, setNotes] = useState(application?.notes ?? '');
  const [validation, setValidation] = useState('');

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!company.trim() || !role.trim()) {
      setValidation('Add a company and role to keep this opportunity clear.');
      return;
    }
    setValidation('');
    onSubmit({ company: company.trim(), role: role.trim(), type, status, location: location.trim(), appliedDate, notes: notes.trim() });
  };
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !pending) onClose(); }}><div className="form-dialog" role="dialog" aria-modal="true" aria-labelledby="application-dialog-title" data-testid="dialog-application-form">
    <div className="dialog-head"><div><div className="eyebrow">{application ? 'KEEP YOUR TRACKER CURRENT' : 'A NEW POSSIBILITY'}</div><h2 className="font-display" id="application-dialog-title">{application ? 'Edit application' : 'Add an application'}</h2><p>{application ? 'Update the details as things move along.' : 'Save the details now. You can fill in the rest later.'}</p></div><button className="modal-close" onClick={onClose} aria-label="Close dialog" disabled={pending} data-testid="button-close-form"><X size={18} /></button></div>
    <form onSubmit={submit} noValidate>
      <div className="form-grid">
        <label className="field full"><span>Company <b>*</b></span><input autoFocus value={company} onChange={(e) => setCompany(e.target.value)} placeholder="e.g. Northstar Studio" required data-testid="input-company" /></label>
        <label className="field full"><span>Role or position <b>*</b></span><input value={role} onChange={(e) => setRole(e.target.value)} placeholder="e.g. Product design intern" required data-testid="input-role" /></label>
        <label className="field"><span>Opportunity type</span><select value={type} onChange={(e) => setType(e.target.value as ApplicationType)} data-testid="select-application-type">{types.map((item) => <option key={item} value={item}>{item}</option>)}</select></label>
        <label className="field"><span>Current status</span><select value={status} onChange={(e) => setStatus(e.target.value as ApplicationStatus)} data-testid="select-application-status">{statuses.map((item) => <option key={item} value={item}>{item}</option>)}</select></label>
        <label className="field"><span>Location</span><input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="City, remote, or hybrid" data-testid="input-location" /></label>
        <label className="field"><span>Date applied</span><input type="date" value={appliedDate} onChange={(e) => setAppliedDate(e.target.value)} data-testid="input-applied-date" /></label>
        <label className="field full"><span>Notes <em>Optional</em></span><textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="A reminder, contact name, or what you’d like to ask…" rows={3} data-testid="input-notes" /></label>
      </div>
      {(validation || error) && <div className="form-error" role="alert" data-testid="status-form-error">{error || validation}</div>}
      <div className="dialog-actions"><button type="button" className="secondary-button" onClick={onClose} disabled={pending} data-testid="button-cancel-application">Cancel</button><button type="submit" className="primary-button" disabled={pending} data-testid="button-save-application">{pending ? 'Saving…' : application ? 'Save changes' : 'Add application'}{!pending && <ArrowRight size={16} />}</button></div>
    </form>
  </div></div>;
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
