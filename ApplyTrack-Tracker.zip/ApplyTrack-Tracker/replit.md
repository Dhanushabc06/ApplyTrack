# ApplyTrack

A beginner-friendly job and internship tracker with a dashboard, searchable application list, and persistent create, edit, and delete flows.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/applytrack run dev` — run the ApplyTrack web interface
- `PORT=5001 uv run --project . python artifacts/applytrack/server/app.py` — run the ApplyTrack Flask API from the workspace root
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- ApplyTrack stores data in `artifacts/applytrack/server/applytrack.sqlite3`; it does not require `DATABASE_URL`.

## Stack

- ApplyTrack frontend: React + Vite + TypeScript
- ApplyTrack backend: Python Flask + SQLite
- The workspace also includes a shared Express API and PostgreSQL/Drizzle libraries used by other packages.
- API contract generation: Orval from `lib/api-spec/openapi.yaml`

## Where things live

- `artifacts/applytrack/src/` — dashboard and application-management UI
- `artifacts/applytrack/server/app.py` — Flask API and SQLite schema initialization
- `lib/api-spec/openapi.yaml` — application API contract and generated client source
- `artifacts/applytrack/src/index.css` — app theme

## Architecture decisions

- ApplyTrack uses its own Flask service at `/applytrack-api`; it does not route through the shared Express API.
- SQLite is used for the app's local single-user application tracker; the database file is created on first start.

## Product

Users can review application totals, search and filter job or internship applications, and add, edit, or delete records.

## User preferences

- Keep the interface modern and beginner-friendly.

## Gotchas

- After changing the OpenAPI contract, rerun API code generation before updating frontend API calls.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
